<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="aboutus.css">
</head>
<body>
    <!-- Navigation Bar -->
    <div class="navbar">
        <ul>
            <li><a href="homepage.php">Homepage</a></li>
            <li><a href="aboutus.php">About Us</a></li>
            <li><a href="Blog.php">Blog</a></li>
            <li><a href="index.php">Jadwal</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>About Us</h1>
        <div class="about-section">
            <p>Selamat datang di situs web kami, sebuah platform yang didedikasikan untuk kesehatan mental dan psikologi. Kami percaya bahwa kesehatan mental sama pentingnya dengan kesehatan fisik, dan kami berkomitmen untuk menyediakan informasi dan sumber daya yang dapat membantu individu mengenali dan menjaga kesehatan mental mereka.</p>
            
            <p>Tim kami terdiri dari profesional di bidang psikologi, terapi, dan kesehatan mental yang berpengalaman. Dengan latar belakang yang beragam, anggota tim kami memiliki pengetahuan yang mendalam tentang berbagai aspek kesehatan mental, termasuk terapi kognitif perilaku, terapi perilaku dialektis, dan pendekatan holistik. Kami berusaha untuk menciptakan lingkungan yang aman dan mendukung di mana semua orang dapat berbagi pengalaman, belajar, dan mendapatkan bantuan.</p>

            <h2>Misi Kami</h2>
            <p>Misi kami adalah untuk meningkatkan kesadaran akan pentingnya kesehatan mental dan memberikan dukungan kepada individu yang mengalami masalah kesehatan mental. Kami percaya bahwa setiap orang berhak untuk mendapatkan akses ke informasi dan layanan yang mereka butuhkan untuk mencapai kesehatan mental yang optimal.</p>

            <h2>Visi Kami</h2>
            <p>Visi kami adalah menciptakan masyarakat yang lebih terbuka dan sadar akan pentingnya kesehatan mental. Kami ingin menghapus stigma seputar masalah kesehatan mental dan mendorong percakapan yang lebih jujur dan terbuka di antara semua individu. Melalui informasi yang tepat dan dukungan yang tepat, kami percaya setiap orang dapat mencapai kondisi mental yang lebih baik dan menjalani hidup yang lebih memuaskan.</p>

            <h2>Layanan Kami</h2>
            <p>Kami menawarkan berbagai layanan yang dirancang untuk mendukung kesehatan mental Anda, termasuk:</p>
            <ul>
                <li><strong>Artikel Edukasi:</strong> Kami menerbitkan artikel yang informatif tentang berbagai topik terkait kesehatan mental, seperti teknik manajemen stres, cara menghadapi kecemasan, dan banyak lagi.</li>
                <li><strong>Sesi Konseling:</strong> Kami menyediakan layanan konseling untuk individu yang membutuhkan dukungan lebih mendalam. Tim profesional kami siap membantu Anda mengatasi tantangan yang Anda hadapi.</li>
                <li><strong>Forum Diskusi:</strong> Bergabunglah dengan komunitas kami dalam forum diskusi di mana Anda dapat berbagi pengalaman, bertanya, dan mendengarkan cerita orang lain yang juga berjuang dengan isu kesehatan mental.</li>
                <li><strong>Program Pelatihan:</strong> Kami juga menyelenggarakan program pelatihan dan workshop yang bertujuan untuk meningkatkan keterampilan dalam mengelola kesehatan mental, baik untuk individu maupun organisasi.</li>
            </ul>

            <h2>Apa yang Dapat Anda Lakukan?</h2>
            <p>Kesehatan mental adalah tanggung jawab bersama. Kami mengundang Anda untuk:</p>
            <ul>
                <li>Mengunjungi blog kami secara rutin untuk mendapatkan informasi terbaru dan tips kesehatan mental.</li>
                <li>Bergabung dengan forum komunitas kami dan berpartisipasi dalam diskusi untuk saling mendukung.</li>
                <li>Berbicara terbuka tentang kesehatan mental dengan teman dan keluarga untuk mengurangi stigma.</li>
                <li>Mencari bantuan dari tenaga medis profesional jika Anda merasa perlu.</li>
            </ul>

            <p>Terima kasih telah mengunjungi situs kami. Jika Anda memiliki pertanyaan atau ingin berbagi pengalaman, jangan ragu untuk menghubungi kami. Bersama, kita bisa menciptakan lingkungan yang lebih sehat dan mendukung bagi semua.</p>
        </div>

        <!-- Tim Kami Section -->
        <div class="team-section">
            <h2>Tim Kami</h2>
            <div class="image-container">
                <img src="assets/jonathan.jpg" alt="jonathan" class="circular-image">
                <img src="assets/lusida.jpg" alt="lusida" class="circular-image">
                <img src="assets/Dickrullah Brilian A.jpg" alt="Dickrullah" class="circular-image">
            </div>
            <div class="team-names">
                <p>Jonathan Chandra Ivanta</p>
                <p>Lusida Cynthia Winayu</p>
                <p>Dickrullah Brilian Akbar</p>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>&copy; kelompok 2 2024</p>
        <p>Contact us: <a href="mailto:contact@kelompok2.com">contact@kelompok2.com</a></p>
    </div>
</body>
</html>